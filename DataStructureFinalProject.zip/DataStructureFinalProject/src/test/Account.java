package test;

public class Account {
	public String ID;
	public String password;
	public int balance;
	public Account(String ID, String password){
		this.ID = ID;
		this.password = password;
		this.balance = 0;
	}
	public static void main(String[] args){
		
	}
}
